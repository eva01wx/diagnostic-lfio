# Frozen experiment records

Release: contextual-forgetting-2026-10-16.

The results/ directory contains the allocation, rule generalization, initial
and amended feature-forgetting, and contextual-forgetting experiments.
All original results/ payloads are preserved byte for byte, including source
locks, fitting records, exported models, predictions, data splits and timings.
See reproduction/docs/research/REPRODUCE.md in the repository for restoration
and replay commands. BUNDLE_CONTENTS_SHA256.json lists every archive payload.

The contextual extension reuses 648 existing Original source programs on the
same six datasets. Controlled feature costs and synthetic background constraints
are experimental scenarios. benchmark.json contains traced allocation peaks;
benchmark_untraced.json contains separate CPU repetitions on the same 32 cases.
