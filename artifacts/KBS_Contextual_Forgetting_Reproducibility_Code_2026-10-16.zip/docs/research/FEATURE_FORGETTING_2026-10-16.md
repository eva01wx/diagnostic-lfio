# 全局数值特征遗忘与缺失输入证书

按指定的原始数值特征整体遗忘，输出必要条件 U、充分条件 L 和拒绝确定的区域。
这项功能独立于此前的局部条件删除、区间合并及统计校准，不改写那些冻结的实验。

## 使用接口

```python
import numpy as np
from src.feature_forgetting import FeatureForgetter

# model 是已训练的 GeneralizedLFIO；也可直接提供 RuleProgram。
envelope = FeatureForgetter().fit(model.program_, features=[3])

# 完整宽度输入：被遗忘列可以为 NaN，其值不会被访问。
partial = X_test.copy()
partial[:, 3] = np.nan
prediction = envelope.predict(partial)  # 0 / 1 / -1；-1 表示保留不确定
explanation = envelope.explain(partial[0])
formulas = envelope.get_rules(feature_names)
certificate = envelope.export()

# 也可以只传剩余列，顺序由 retained_features_ 给出。
kept = X_test[:, envelope.retained_features_]
assert np.array_equal(prediction, envelope.predict(kept, retained_only=True))

# 反序列化时重新计算证书，不直接相信保存的成功标记。
restored = FeatureForgetter.from_export(certificate)
```

`features=[j,k]` 联合遗忘两个特征；空集合及全部特征也有明确语义。
遗忘从未出现的特征使用直接恒等证明，不消耗补集计算限额。

## 保证的内容

对原代理的头类别公式 F、保留输入 r、被遗忘输入 s：

\[
U(r)=\exists sF(r,s),\quad L(r)=\neg\exists s\neg F(r,s),\quad L\Rightarrow F\Rightarrow U.
\]

- L 成立：无论补充何种被遗忘特征取值，都输出原代理的头类别。
- U 不成立：所有补全都输出默认类别。
- U 成立而 L 不成立：若两侧计算精确，则两种类别都有可能；若计算资源耗尽，则
  标记 unresolved，不冒充已经证实存在两种补全。

存在量化必须先消除矛盾区间，再删除指定特征的全部阈值；例如
`x>2 AND x<=1` 不得在遗忘 x 后变成 TRUE。全称条件通过两次区间补集构造，默认
最多 50,000 次区间减法、4,096 个中间盒。耗尽时保留精确 U，令 L=FALSE 并明确
标记 conservative。这仍允许安全地确认部分默认类输入。

量化覆盖所有有限实数补全，输入数组采用 float64；在极端浮点阈值处，存在的实数
补全不一定有可表示的 float64 实例。解释返回符号区间而非舍入的见证值。
不从数据最小/最大值推断合法范围，也不自动假定特征间的流形或业务约束，因此某些
可能补全会离开观测数据分布。这是既定数学问题的边界，不是因果干预。

证书针对传入的那个代理。若输入是校准泛化后的模型，证书只保证它自己的补全一致性，
不额外保证与原模型、教师或真实标签一致。无需 iid 或校准假设即可解释这个确定性
证书，但不能将其升级成教师级正确性证书。

## 可执行示例

设头类别公式为 `(x>0 AND y>0) OR (x<=0 AND z>0)`，遗忘 x 后：

- 必要条件 U：`y>0 OR z>0`。
- 充分条件 L：`y>0 AND z>0`。
- y、z 均为正时确认头类别，均非正时确认默认类，符号相反时需要补充 x。

当前算法没有寻找最小特征解释，也未求最大体积的局部解释。L、U 的合计条件数
可能比 F 多；实验单独报告这种增长和编译 CPU，不宣称遗忘必然压缩或加速推理。
可执行解释与结构量不是人类理解度实验。

## 实验与复现

复用此前六数据集、72 教师设置、三个基模型及三个预算的 648 组已完成拟合，分别
投影 Original 和 BoundedGeneralize，共 1,296 个来源程序，不计作新增拟合或外部
验证。编译所有已使用单特征，以及覆盖率选择策略和固定索引策略所需的联合查询。
坐标选择只读取 selection 分区；公式、选择和训练中位数先保存，再访问测试输入。
未使用特征的恒等对照单独统计，避免它们抬高主要覆盖率。

```bash
venv/bin/python -m pytest -q tests/test_feature_forgetting.py
venv/bin/python generate_feature_forgetting.py --workers 16
venv/bin/python build_paper.py --all
venv/bin/python package_feature_forgetting.py
```

当前记录为 `results/feature_forgetting_20261016_v2/`。首次计算中的恒等分支效率缺陷、
失败审计和初版源码保留在归档中；原始结果为 `results/feature_forgetting_20261016/`。
窄范围修订见 `FEATURE_FORGETTING_AMENDMENT_2026-10-16.md`，实验限额、策略、数据
和端点未改。全量重算使用新的 v2 目录，没有覆盖初版记录。

新执行应使用独立目录，先 `run_feature_forgetting.py --prepare-only` 冻结配置，再
`run_feature_forgetting.py --workers 16`。若独立副本中包含发布的 v2 记录，先将副本
内该结果目录重命名保留，才能触发新计算；原工作区的快照保持原位。不要修改已
冻结源码后继续写入同一结果目录。
独立审计使用直接规则求值遍历被遗忘坐标的所有阈值单元，核对 selection/test 上
每个保留输入，不复用编译器的补集算法；同时重放选择策略、中位数和保存的预测。

## 已完成结果

全部 1,296 个来源程序重算完成，共 14,834 个遗忘查询。对每个模型，单特征选择策略
只在 selection 分区挑选可确认覆盖率最高的已使用特征；它不代表任意特征缺失时的
表现。数据集等权结果如下：

| 来源程序 | 遗忘策略 | 合格模型数 | 测试可确认覆盖率 |
| --- | --- | ---: | ---: |
| Original | 固定单特征 | 648 | 61.0% |
| Original | 选择单特征 | 648 | **80.8%** |
| Original | 固定两特征 | 610 | 36.0% |
| Original | 选择两特征 | 610 | **61.4%** |
| BoundedGeneralize | 选择单特征 | 648 | 79.5% |
| BoundedGeneralize | 选择两特征 | 607 | 59.3% |

Original 单特征选择的描述性六数据集簇区间为 [74.0%, 87.2%]，对固定索引策略的
配对覆盖率增益为 +19.8 个百分点，区间 [12.7, 26.9]。对所有已使用单特征先在每个
来源模型内平均，覆盖率为 63.8%，没有通过挑选容易遗忘的坐标抬高这一结果。
单特征选择在来源头类别／默认类别的非空子集上，覆盖率分别为 77.3%／80.8%。

独立审计检查 16,187,153 次保留输入查询（selection/test，含重复使用）、86,476 组
阈值单元枚举。7,551,125 次已确定测试查询均与其来源代理一致；这些重复查询数量
不作为独立统计样本数。恒等分支修订恢复了 22 个未使用特征对照，非对照投影公式及
所有选择策略均与首轮一致。

资源限额导致 752/14,834 个查询使用保守下界，不能称为完整精确的全称投影；对应
预测仍遵守 L⇒F⇒U。主要单特征选择的全称计算完成率为 98.6%。

**表示开销是实质限制。** Original 单特征选择中，72.2% 模型的 L、U 合计条件数比
来源程序更多；合计条件数中位数为 21、最大值为 4,379。中位编译 CPU 约 0.66ms，
不等于端到端推理加速。这项结果支持缺失信息下的确定性证书，未证明总体更易阅读、
人类理解更好或规则始终更短。中位数填补和只用存在投影的强制分类器均不拒答，其
误差不能直接与选择性预测的误差混为同一分母。

完整工作区测试 151 项通过。审计、图表、逐查询数据、修订对照及可执行示例见
`feature_forgetting_2026-10-16/`。冻结协议和科学结论中的经典理论出处均保留。

## 理论来源和贡献边界

Lin 与 Reiter 1994 的遗忘、Lin 2001 的必要／充分条件对偶、以及形式 XAI 中的
充分理由都是已有理论。已补充 Darwiche/Hirth 2020 和 Izza 等 2025 的相关工作，
避免将当前实现称为新的遗忘理论或最一般的解释算法。贡献是数值阈值一致性、资源
受限且保守失败的全局特征投影、缺失输入证书及完整可重放的集成评估。

当前论文、生成表格、图、逐查询指标、审计及复现 ZIP 位于
`feature_forgetting_2026-10-16/`；主稿仍为 `LFIO_Negation_Paper.pdf`。
