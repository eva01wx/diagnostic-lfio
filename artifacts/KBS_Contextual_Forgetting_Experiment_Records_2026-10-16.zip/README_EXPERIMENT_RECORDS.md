# Frozen allocation, generalization and forgetting records

Current release: contextual-forgetting-2026-10-16.
Title: Compact Rule Distillation with Diagnostic Allocation and Certified Feature Forgetting.
Package index: docs/research/CURRENT_RELEASE.md.
Release directory: docs/research/contextual_forgetting_2026-10-16/.

The new extension is results/contextual_forgetting_20261016. Earlier cohorts
and the initial/amended global feature-forgetting records retain their names.
The extension uses 648 existing Original source programs; choices/candidates
were saved before test inference. Controlled cost scenarios and known synthetic
background constraints are distinct from verified real-world acquisition costs
or domain assumptions. All saved vectors and choices are replayable.
benchmark.json contains traced allocation measurements; benchmark_untraced.json
contains separate CPU repetitions on exactly the same 32 stress cases.
